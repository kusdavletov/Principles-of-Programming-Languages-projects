# Note: If Exp and Value are empty classes, we do not need them in a
# dynamically typed language, but they help show the structure and they
# can be useful places for code that applies to multiple subclasses.

class Exp:
    # could put default implementations or helper methods here
    pass

class Value(Exp):
  # this is overkill here, but is useful if you have multiple kinds of
  # /values/ in your language that can share methods that do not make sense 
  # for non-value expressions
  pass

class Int(Value):
    def __init__(self, i):
        self.i = i
    def eval(self): # no argument because no environment
        return self
    def __str__(self):
        return str(self.i)
    def hasZero(self):
        return self.i==0
    def noNegConstants(self):
        if self.i < 0:
            return Negate(int(-self.i))
        else:
            return self
 
class Negate(Exp):
    def __init__(self, e):
        self.e = e
    def eval(self):
        return int(-e.eval().i) # error if e.eval has no i attribute
    def __str__(self):
        return "-(" + str(e) + ")"
    def hasZero(self):
        return self.e.hasZero()
    def noNegConstants(self):
        return Negate(self.e.noNegConstants())

class Add(Exp):
    def __init__(self,e1,e2):
        self.e1 = e1
        self.e2 = e2
    def eval(self):
        return int(self.e1.eval().i + self.e2.eval().i) # error if e1.eval or e2.eval has no i attr 
    def __str__(self):
        return "(" + str(self.e1) + " + " + str(self.e2) + ")"
    def hasZero(self):
        return self.e1.hasZero() or self.e2.hasZero()
    def noNegConstants(self):
        return Add(self.e1.noNegConstants(), self.e2.noNegConstants())
