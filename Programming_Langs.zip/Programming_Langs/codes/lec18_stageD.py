# Note: If Exp and Value are empty classes, we do not need them in a
# dynamically typed language, but they help show the structure and they
# can be useful places for code that applies to multiple subclasses.

from multimethods import multimethod

class Exp:
    # could put default implementations or helper methods here
    pass

class Value(Exp):
  # this is overkill here, but is useful if you have multiple kinds of
  # /values/ in your language that can share methods that do not make sense 
  # for non-value expressions
  pass

def add_values(a, b):
class Int(Value):
    def __init__(self, i):
        self.i = i
    def eval(self): # no argument because no environment
        return self
    def __str__(self):
        return str(self.i)
    def hasZero(self):
        return self.i==0
    def noNegConstants(self):
        if self.i < 0:
            return Negate(int(-self.i))
        else:
            return self
    def add_values(self, v): # first dispatch
        return v.addInt(self)
    def addInt(self, v): # second dispatch: other is Int
        return int(v.i + self.i)
    def addString(self, v): # second dispatch: other is MyString (notice order flipped)
        return MyString(v.s + str(self.i))
    def addRational(self, v): # second dispatch: other is MyRational
        return MyRational(v.i+v.j*self.i,v.j)

# new value classes
class MyString(Value):
    def __init__(self, s):
        self.s = s
    def eval(self):
        return self
    def __str__(self):
        return self.s
    def hasZero(self):
        return False
    def noNegConstants(self):
        return self
    # double-dispatch for adding values
    def add_values(self, v): # first dispatch
        return v.addString(self)
    def addInt(self, v): # second dispatch: other is Int (notice order is flipped)
        return MyString(str(v.i) + self.s)
    def addString(self, v): # second dispatch: other is MyString (notice order flipped)
        return MyString(v.s + self.s)
    def addRational(self, v): # second dispatch: other is MyRational (notice order flipped)
        return MyString(str(v.i) + "/" + str(v.j) + self.s)

class MyRational(Value):
    def __init__(self, i,j):
        self.i = i
        self.j = j
    def eval(self):
        return self
    def __str__(self):
        return str(self.i) + "/" + str(self.j)
    def hasZero(self):
        return self.i==0
    def noNegConstants(self):
        if self.i < 0 and self.j < 0:
            return MyRational(-self.i,-self.j)
        elif self.j < 0:
            return Negate(MyRational(self.i,-self.j))
        elif self.i < 0:
            return Negate(MyRational.new(-self.i,self.j))
        else:
            return self
  # double-dispatch for adding values
    def add_values(self, v): # first dispatch
        return v.addRational(self)
    def addInt(self, v): # second dispatch
        return v.addRational(self) # reuse computation of commutative operation
    def addString(self, v): # second dispatch: other is MyString (notice order flipped)
        return MyString(v.s + str(self.i) + "/" + str(self.j))
    def addRational(self, v): # second dispatch: other is MyRational (notice order flipped)
        a,b,c,d = self.i,self.j,v.i,v.j
        return MyRational(a*d+b*c,b*d)

class Negate(Exp):
    def __init__(self, e):
        self.e = e
    def eval(self):
        return int(-e.eval().i) # error if e.eval has no i attribute
    def __str__(self):
        return "-(" + str(e) + ")"
    def hasZero(self):
        return self.e.hasZero()
    def noNegConstants(self):
        return Negate(self.e.noNegConstants())

@multimethod(Int, Int)
def multi_add_values(a, b):
    return a+b
@multimethod(Int, String)
def multi_add_values(a, b):
    return str(a)+b
@multimethod(Int, MyRational)
def multi_add_values(a, b):
    return MyRational(b.i+b.j*a, b.j)

# add 6 more combinations

class Add(Exp):
    def __init__(self,e1,e2):
        self.e1 = e1
        self.e2 = e2
    def eval(self):
        return multi_add_values(self.e1.eval(), self.e2.eval())
    def __str__(self):
        return "(" + str(self.e1) + " + " + str(self.e2) + ")"
    def hasZero(self):
        return self.e1.hasZero() or self.e2.hasZero()
    def noNegConstants(self):
        return Add(self.e1.noNegConstants(), self.e2.noNegConstants())

class Mult(Exp):
    def __init__(self,e1,e2):
        self.e1 = e1
        self.e2 = e2
    def eval(self):
        return int(self.e1.eval().i * self.e2.eval().i) # error if e1.eval or e2.eval has no i method
    def __str__(self):
        return "(" + sefl.e1.toString + " * " + sefl.e2.toString + ")"
    def hasZero(self):
        return self.e1.hasZero() or self.e2.hasZero()
    def noNegConstants(self):
        return Mult(self.e1.noNegConstants(), self.e2.noNegConstants())

